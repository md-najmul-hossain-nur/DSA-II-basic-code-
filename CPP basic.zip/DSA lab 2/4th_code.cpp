

#include<bits/stdc++.h>
using namespace std;

bool comp(int a, int b)
{
    return a>b;
}
int main()
{
    int arr[]= { 100,512,6,724,31,14,2,8};
    int len= sizeof(arr)/sizeof(arr[0]);
    for(int i= 0; i<len; i++)
    {
        printf("%d  ",arr[i]);

    }
    printf("\n");
    sort(arr,arr+len,comp);
    for(int i=0; i<len; i++)
    {
        printf("%d ",arr[i]);
    }
    printf("\n");
    return 0;



}
// print----- 724 512 100 31 14 8 6 2

